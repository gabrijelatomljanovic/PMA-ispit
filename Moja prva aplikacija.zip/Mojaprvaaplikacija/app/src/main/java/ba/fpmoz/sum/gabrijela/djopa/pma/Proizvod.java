package ba.fpmoz.sum.gabrijela.djopa.pma;

public class Proizvod {
    public Proizvod(String proizvodName, String proizvodPrice) {
    }
}
