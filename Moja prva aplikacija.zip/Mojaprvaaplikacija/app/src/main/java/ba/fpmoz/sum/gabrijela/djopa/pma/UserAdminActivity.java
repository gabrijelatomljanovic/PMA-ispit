package ba.fpmoz.sum.gabrijela.djopa.pma;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import ba.fpmoz.sum.gabrijela.djopa.pma.model.proizvod;

public class UserAdminActivity extends AppCompatActivity {
    FirebaseDatabase db;
    DatabaseReference ref;
    EditText proizvodNameInp;
    EditText proizvodPriceInp ;
    ImageView proizvodView ;
    Button addBtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_admin);

        this.db = FirebaseDatabase.getInstance();
        this.ref = this.db.getReference("trgovina/proizvodi");

        this.proizvodNameInp = findViewById(R.id.proizvodNameInp);
        this.proizvodPriceInp = findViewById(R.id.proizvodPriceInp);
        this.proizvodView = findViewById(R.id.proizvodView);
        this.addBtn = findViewById(R.id.addBtn);


        this.addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String proizvodName = proizvodNameInp.getText().toString();
                String proizvodPrice = proizvodPriceInp.getText().toString();

                ref.push().setValue(new proizvod(proizvodName,proizvodPrice));
                proizvodNameInp.setText("");
                proizvodPriceInp.setText("");
                Toast.makeText(getApplicationContext(), "Uspješno unesen proizvod", Toast.LENGTH_LONG).show();


            }
        });

    }
}